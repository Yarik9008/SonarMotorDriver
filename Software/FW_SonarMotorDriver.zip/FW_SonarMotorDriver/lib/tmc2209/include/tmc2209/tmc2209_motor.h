/**
 * @file tmc2209_motor.h
 * @brief Высокоуровневый фасад (API) для управления шаговым двигателем через TMC2209.
 *
 * Данный модуль абстрагирует низкоуровневые регистры TMC2209 и физический транспорт
 * (STEP/DIR или UART), предоставляя приложению простой интерфейс: "ехать", "стоять",
 * "установить ток" и т.д.
 */

#ifndef TMC2209_MOTOR_H
#define TMC2209_MOTOR_H

#include <stdint.h>
#include "tmc2209_types.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * @brief Режимы управления движением.
 */
typedef enum {
    TMC2209_MOTOR_CONTROL_STEP_DIR = 0, ///< Управление через импульсы STEP/DIR (аппаратный ШИМ)
    TMC2209_MOTOR_CONTROL_UART     = 1  ///< Управление через регистр VACTUAL по UART
} tmc2209_motor_mode_t;

/**
 * @brief Снимок текущей конфигурации мотора.
 */
typedef struct {
    uint16_t             run_ma;      ///< Рабочий ток, мА
    uint16_t             hold_ma;     ///< Ток удержания, мА
    uint16_t             microsteps;  ///< Дробление шага (1..256)
    tmc2209_motor_mode_t mode;        ///< Текущий режим (STEP/DIR или UART)
    uint8_t              ready;       ///< Флаг готовности драйвера
} tmc2209_motor_config_t;

/* ---- Инициализация и фоновая задача ---- */

/**
 * Инициализация подсистемы мотора без изменения политики включения драйвера.
 * Момент вызова tmc2209_motor_set_enabled() определяет приложение.
 * Возвращает 0 при успехе, <0 при ошибке.
 */
int  tmc2209_motor_init(void);

/**
 * Периодическая задача, вызывать из главного цикла.
 * Обрабатывает неблокирующую диагностику и фоновое обслуживание.
 */
void tmc2209_motor_task(void);

/** Возвращает 1, если подсистема мотора инициализирована и связь с чипом подтверждена. */
int  tmc2209_motor_is_ready(void);

/* ---- Базовое управление ---- */

/**
 * Включить или выключить драйвер (управление выводом ENN).
 * Возврат: 0=OK, -1=не готов, -2=неверный аргумент, -3=ошибка применения.
 */
int tmc2209_motor_set_enabled(int enabled);

/** Немедленно остановить любое движение. */
void tmc2209_motor_stop(void);

/**
 * Возвращает 1, если мотор в состоянии «команда на движение»
 * (импульсы ШИМ активны или VACTUAL ненулевой).
 * Примечание: не гарантирует реальное движение при выключенном или застопоренном драйвере.
 */
int  tmc2209_motor_is_moving(void);

/* ---- Команды движения ---- */

/**
 * Непрерывная скорость STEP/DIR: steps_per_s импульсов в секунду.
 * 0 = остановка. ШИМ TIM4 работает без перезапуска каждый тик контура.
 * В режиме UART: эквивалент VACTUAL (steps_per_s * 256).
 */
void tmc2209_motor_set_step_rate(uint32_t steps_per_s, int8_t dir_cw);

/**
 * Одноразовая серия из |steps| импульсов (доводка в deadband).
 * Для непрерывного движения используйте tmc2209_motor_set_step_rate().
 */
void tmc2209_motor_move_steps(int32_t steps);

/** Движение с заданной скоростью (только режим UART). */
void tmc2209_motor_move_velocity(int32_t velocity);

/** Обработчик TIM4 для одноразовых серий (STEP/DIR, из HAL_TIM_PeriodElapsedCallback). */
void tmc2209_motor_tim4_period_elapsed(void);

/* ---- Конфигурация ---- */

/**
 * Установить ток движения и удержания в мА.
 * Возврат: 0=OK, -1=не готов, -2=неверный аргумент, -3=ошибка применения.
 */
int  tmc2209_motor_set_current(uint16_t run_ma, uint16_t hold_ma);

/**
 * Установить разрешение микрошагов (1, 2, 4, …, 256).
 * Возврат: 0=OK, -1=не готов, -2=неверный аргумент, -3=ошибка применения.
 */
int  tmc2209_motor_set_microsteps(uint16_t microsteps);

/** Получить текущую конфигурацию мотора. */
void tmc2209_motor_get_config(tmc2209_motor_config_t *cfg);

/** Получить режим управления (STEP/DIR или UART). */
tmc2209_motor_mode_t tmc2209_motor_get_control_mode(void);

/* ---- Диагностика ---- */

/** Получить версию чипа. */
int  tmc2209_motor_get_version(uint8_t *version);

/** Получить полный статус драйвера (блокирующее чтение по UART). */
int  tmc2209_motor_get_drv_status(tmc2209_drv_status_t *st);

/** Получить кэшированный статус драйвера (неблокирующий, обновляется в task). */
int  tmc2209_motor_get_cached_drv_status(tmc2209_drv_status_t *st);

#ifdef __cplusplus
}
#endif

#endif /* TMC2209_MOTOR_H */
