/* tmc2209.c — Единый app-level Motor Facade: TMC2209 + STEP/DIR + UART motion.
 *
 * Единственный владелец пина ENN.
 * Управление драйвером осуществляется через чистую библиотеку lib/tmc2209.
 * Backend: STEP_DIR (TIM4 PWM) или UART (VACTUAL) задаётся MOTOR_DRIVER_MODE.
 *
 * STEP/DIR backend — continuous timer model:
 *   Таймер TIM4 запускается один раз при начале движения и работает непрерывно.
 *   На каждый control tick изменяются только ARR/CCR, если параметры движения
 *   реально изменились. Нет stop/start на каждый тик.
 *   Остановка — только при steps == 0 или TMC2209_Stop().
 *
 * TMC2209 диагностика — неблокирующий отложенный опрос:
 *   Диагностика (DRV_STATUS) читается в фоне через TMC2209_Task().
 *   Запрос ставится в очередь, результат асинхронно доступен через
 *   TMC2209_GetCachedDrvStatus(). Init остаётся блокирующим.
 */

#include "tmc2209.h"
#include "board.h"
#include "tmc2209_port_stm32_hal.h"
#include "tmc2209/tmc2209.h"

/* ---- TMC2209 core state ---- */

static tmc2209_t          s_drv;
static UART_HandleTypeDef  s_huart;
static tmc2209_hal_ctx_t   s_hal;
static uint8_t            s_tmc_ready = 0;

/* Последние успешно применённые настройки (обновляются только при успехе). */
static uint16_t s_run_ma    = TMC2209_IRUN_MA;
static uint16_t s_hold_ma   = TMC2209_IHOLD_MA;
static uint16_t s_microsteps = TMC2209_MICROSTEPS;

static int tmc2209_init_blocking(void)
{
    s_huart.Instance          = TMC2209_UART;
    s_huart.Init.BaudRate     = TMC2209_UART_BAUDRATE;
    s_huart.Init.WordLength   = UART_WORDLENGTH_8B;
    s_huart.Init.StopBits     = UART_STOPBITS_1;
    s_huart.Init.Parity       = UART_PARITY_NONE;
    s_huart.Init.Mode         = UART_MODE_TX_RX;
    s_huart.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
    s_huart.Init.OverSampling = UART_OVERSAMPLING_16;
    HAL_UART_Init(&s_huart);

    s_hal.huart       = &s_huart;
    s_hal.en_port     = ENABLE_PORT;
    s_hal.en_pin      = ENABLE_PIN;
    s_hal.sysclk_hz   = SYSCLK_HZ;
    s_hal.half_duplex = TMC2209_HALF_DUPLEX;
    s_hal.debug_fn    = NULL;

    tmc2209_io_t io;
    tmc2209_port_stm32_hal_fill_io(&io, &s_hal);

    tmc2209_config_t cfg = TMC2209_DEFAULT_CONFIG;
    cfg.addr           = TMC2209_UART_ADDR;
    cfg.rsense         = TMC2209_RSENSE_OHM;
    cfg.irun_ma        = TMC2209_IRUN_MA;
    cfg.ihold_ma       = TMC2209_IHOLD_MA;
    cfg.microsteps     = TMC2209_MICROSTEPS;
    cfg.reply_delay_us = TMC2209_REPLY_DELAY_US;
    cfg.senddelay      = TMC2209_CFG_SENDDELAY;
    cfg.tpowerdown     = TMC2209_TPOWERDOWN;
    cfg.en_spreadcycle = TMC2209_SPREADCYCLE;

    tmc2209_result_t res = tmc2209_init(&s_drv, &cfg, &io);
    if (res == TMC2209_OK) {
        s_tmc_ready = 1;
        return 0;
    }
    return -1;
}

/* ---- STEP/DIR backend — continuous timer model ---- */

#define TICKS_PER_US     (TIM4_CLK_HZ / 1000000U)
#define PULSE_TICKS      (STEP_PULSE_US * TICKS_PER_US)
#define MIN_PERIOD_TICKS (PULSE_TICKS + 1U)

static TIM_HandleTypeDef   htim_step;
static TIM_OC_InitTypeDef  sConfigOC    = {0};
static uint8_t             g_pwm_running = 0;
static int8_t              g_cur_dir     = -1;  /* -1=uninit, 0=CCW, 1=CW */
static uint32_t            g_cur_arr     = 0;   /* текущий ARR; 0=не настроен */

static void stepdir_set_dir(int8_t dir_cw)
{
    HAL_GPIO_WritePin(DIR_PORT, DIR_PIN, dir_cw ? GPIO_PIN_SET : GPIO_PIN_RESET);
    g_cur_dir = dir_cw;
}

static void stepdir_init(void)
{
    GPIO_InitTypeDef gpio = {0};
    gpio.Pin   = STEP_PIN;
    gpio.Mode  = GPIO_MODE_AF_PP;
    gpio.Speed = GPIO_SPEED_FREQ_HIGH;
    gpio.Pull  = GPIO_NOPULL;
    HAL_GPIO_Init(STEP_PORT, &gpio);
    HAL_GPIO_WritePin(STEP_PORT, STEP_PIN, GPIO_PIN_RESET);

    gpio.Pin   = DIR_PIN;
    gpio.Mode  = GPIO_MODE_OUTPUT_PP;
    HAL_GPIO_Init(DIR_PORT, &gpio);
    HAL_GPIO_WritePin(DIR_PORT, DIR_PIN, GPIO_PIN_RESET);

    /* ENN pin: lib/tmc2209 — владелец; инициализируем в безопасное состояние */
    gpio.Pin = ENABLE_PIN;
    HAL_GPIO_Init(ENABLE_PORT, &gpio);
    HAL_GPIO_WritePin(ENABLE_PORT, ENABLE_PIN, GPIO_PIN_SET);

    htim_step.Instance               = TIM4;
    htim_step.Init.Prescaler         = 0;
    htim_step.Init.CounterMode       = TIM_COUNTERMODE_UP;
    htim_step.Init.Period            = 999;
    htim_step.Init.ClockDivision     = TIM_CLOCKDIVISION_DIV1;
    htim_step.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_ENABLE;   /* Preload: обновление ARR на границе периода */
    HAL_TIM_PWM_Init(&htim_step);

    sConfigOC.OCMode       = TIM_OCMODE_PWM1;
    sConfigOC.OCPolarity   = TIM_OCPOLARITY_HIGH;
    sConfigOC.OCFastMode   = TIM_OCFAST_DISABLE;
    sConfigOC.Pulse        = PULSE_TICKS;
    HAL_TIM_PWM_ConfigChannel(&htim_step, &sConfigOC, TIM_CHANNEL_3);

    g_pwm_running = 0;
    g_cur_dir     = -1;
    g_cur_arr     = 0;
}

void HAL_TIM_PWM_MspInit(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == TIM4)
        __HAL_RCC_TIM4_CLK_ENABLE();
}

static void stepdir_stop(void)
{
    if (g_pwm_running) {
        HAL_TIM_PWM_Stop(&htim_step, TIM_CHANNEL_3);
        HAL_GPIO_WritePin(STEP_PORT, STEP_PIN, GPIO_PIN_RESET);
        g_pwm_running = 0;
        g_cur_arr     = 0;
    }
}

/* Continuous timer model:
 *   - При первом вызове с ненулевым steps — запускаем таймер.
 *   - При повторных вызовах — обновляем ARR/CCR только если изменились.
 *   - Направление меняем только при смене знака.
 *   - При steps == 0 — останавливаем.
 */
static void stepdir_steps(int32_t steps)
{
    if (steps == 0) {
        stepdir_stop();
        return;
    }

    uint32_t n   = (uint32_t)(steps < 0 ? -steps : steps);
    int8_t   dir = (steps > 0) ? 1 : 0;

    /* Обновляем направление только при реальном изменении */
    if (dir != g_cur_dir)
        stepdir_set_dir(dir);

    /* Рассчитываем новый ARR */
    uint32_t period_us = 1000U / n;
    if (period_us < STEP_PULSE_US + 1U)
        period_us = STEP_PULSE_US + 1U;

    uint32_t arr = period_us * TICKS_PER_US;
    if (arr < MIN_PERIOD_TICKS) arr = MIN_PERIOD_TICKS;
    if (arr > 65535U)           arr = 65535U;

    uint32_t ccr = (PULSE_TICKS < arr) ? PULSE_TICKS : (arr / 2U);

    if (!g_pwm_running) {
        /* Первый запуск — настраиваем и стартуем */
        __HAL_TIM_SET_AUTORELOAD(&htim_step, arr - 1U);
        __HAL_TIM_SET_COMPARE(&htim_step, TIM_CHANNEL_3, ccr);
        __HAL_TIM_SET_COUNTER(&htim_step, 0);
        HAL_TIM_PWM_Start(&htim_step, TIM_CHANNEL_3);
        g_pwm_running = 1;
        g_cur_arr     = arr;
    } else if (arr != g_cur_arr) {
        /* Только обновляем ARR/CCR на лету — без stop/start.
         * TIM_AUTORELOAD_PRELOAD_ENABLE гарантирует, что ARR
         * будет применён только на следующей границе периода. */
        __HAL_TIM_SET_AUTORELOAD(&htim_step, arr - 1U);
        __HAL_TIM_SET_COMPARE(&htim_step, TIM_CHANNEL_3, ccr);
        g_cur_arr = arr;
    }
    /* else arr == g_cur_arr && running — ничего не делаем */
}

/* ---- TMC2209 diagnostic task — неблокирующий отложенный опрос ---- */

#define DIAG_INTERVAL_MS   500U   /* Период опроса DRV_STATUS, мс */

typedef enum {
    DIAG_IDLE = 0,
    DIAG_PENDING,
    DIAG_DONE
} DiagState;

static volatile DiagState      s_diag_state  = DIAG_IDLE;
static tmc2209_drv_status_t    s_diag_cached = {0};
static uint8_t                 s_diag_valid  = 0;
static uint32_t                s_diag_last_ms = 0;

/* Планирует следующий опрос DRV_STATUS.
 * Вызывается из main loop через TMC2209_Task().
 * Выполняет одну транзакцию (blocking) только когда настал срок.
 * Для данного проекта это «минимально допустимый» вариант:
 * blocking только на одной UART-транзакции ~300 мкс раз в 500 мс.
 */
static void diag_task(void)
{
    if (!s_tmc_ready)
        return;

    /* Используем DWT для измерения времени */
    extern void Delay_Init(void);       /* задекларирован в board.h */
    uint32_t now_ms = HAL_GetTick();
    if (now_ms - s_diag_last_ms < DIAG_INTERVAL_MS)
        return;

    s_diag_last_ms = now_ms;
    s_diag_state   = DIAG_PENDING;

    tmc2209_drv_status_t st = {0};
    tmc2209_result_t res = tmc2209_get_drv_status(&s_drv, &st);
    if (res == TMC2209_OK) {
        s_diag_cached = st;
        s_diag_valid  = 1;
        s_diag_state  = DIAG_DONE;
    } else {
        s_diag_state  = DIAG_IDLE;
    }
}

/* ---- Public Motor Facade API ---- */

int TMC2209_Init(void)
{
    if (tmc2209_init_blocking() != 0)
        return -1;

#if MOTOR_DRIVER_MODE == MOTOR_DRIVER_MODE_STEP_DIR_VAL
    stepdir_init();
#endif

    tmc2209_disable(&s_drv);
    s_diag_last_ms = 0;
    return 0;
}

uint8_t TMC2209_IsReady(void)
{
    return s_tmc_ready;
}

TMC2209_ControlMode TMC2209_GetControlMode(void)
{
#if MOTOR_DRIVER_MODE == MOTOR_DRIVER_MODE_UART_VAL
    return TMC2209_CONTROL_MODE_UART;
#else
    return TMC2209_CONTROL_MODE_STEP_DIR;
#endif
}

void TMC2209_SetEnabled(uint8_t enabled)
{
    if (!s_tmc_ready) return;
    if (enabled)
        tmc2209_enable(&s_drv);
    else
        tmc2209_disable(&s_drv);
}

int TMC2209_SetCurrent(uint16_t run_ma, uint16_t hold_ma)
{
    if (!s_tmc_ready) return -1;
    /* Допустимый диапазон: 0..3000 мА (ограничение разумное для большинства моторов) */
    if (run_ma > 3000 || hold_ma > 3000) return -2;
    if (tmc2209_set_current(&s_drv, run_ma, hold_ma) != TMC2209_OK) return -3;
    /* Обновляем кэш только после успешного применения */
    s_run_ma  = run_ma;
    s_hold_ma = hold_ma;
    return 0;
}

/* Допустимые значения микрошагов для TMC2209 */
static const uint16_t k_valid_mstep[] = {1, 2, 4, 8, 16, 32, 64, 128, 256};
#define VALID_MSTEP_COUNT (sizeof(k_valid_mstep) / sizeof(k_valid_mstep[0]))

int TMC2209_SetMicrosteps(uint16_t microsteps)
{
    if (!s_tmc_ready) return -1;
    /* Принимаем только значения из фиксированного набора */
    uint8_t valid = 0;
    for (uint8_t i = 0; i < VALID_MSTEP_COUNT; i++) {
        if (k_valid_mstep[i] == microsteps) { valid = 1; break; }
    }
    if (!valid) return -2;
    if (tmc2209_set_microsteps(&s_drv, microsteps) != TMC2209_OK) return -3;
    s_microsteps = microsteps;
    return 0;
}

int TMC2209_GetConfig(TMC2209_Config *cfg)
{
    if (!cfg) return -1;
    cfg->run_ma     = s_run_ma;
    cfg->hold_ma    = s_hold_ma;
    cfg->microsteps = s_microsteps;
    cfg->mode       = TMC2209_GetControlMode();
    cfg->ready      = s_tmc_ready;
    return 0;
}

void TMC2209_MoveSteps(int32_t steps)
{
#if MOTOR_DIR_INVERT
    steps = -steps;
#endif

#if MOTOR_DRIVER_MODE == MOTOR_DRIVER_MODE_STEP_DIR_VAL
    stepdir_steps(steps);
#else
    if (steps == 0) {
        tmc2209_stop(&s_drv);
        return;
    }
    int32_t v = steps * 256;
    if (v > 8388607)  v = 8388607;
    if (v < -8388608) v = -8388608;
    tmc2209_set_vactual(&s_drv, v);
#endif
}

void TMC2209_MoveVelocity(int32_t velocity)
{
#if MOTOR_DRIVER_MODE == MOTOR_DRIVER_MODE_UART_VAL
    if (!s_tmc_ready) return;
    if (velocity > 8388607)  velocity = 8388607;
    if (velocity < -8388608) velocity = -8388608;
    tmc2209_set_vactual(&s_drv, velocity);
#else
    (void)velocity;
#endif
}

void TMC2209_Stop(void)
{
#if MOTOR_DRIVER_MODE == MOTOR_DRIVER_MODE_STEP_DIR_VAL
    stepdir_stop();
#else
    tmc2209_stop(&s_drv);
#endif
}

uint8_t TMC2209_IsMoving(void)
{
#if MOTOR_DRIVER_MODE == MOTOR_DRIVER_MODE_STEP_DIR_VAL
    return g_pwm_running;
#else
    /* В UART-режиме нет простого способа без чтения регистра — считаем по флагу ready */
    return s_tmc_ready ? 0 : 0;  /* TODO: отслеживать VACTUAL != 0 при необходимости */
#endif
}

/* Вызывается из main loop.
 * Выполняет периодический опрос DRV_STATUS без блокировки управляющего цикла.
 * Одна транзакция ~300 мкс раз в 500 мс — незначительная нагрузка.
 */
void TMC2209_Task(void)
{
    diag_task();
}

int TMC2209_GetVersion(uint8_t *version)
{
    if (!s_tmc_ready || !version) return -1;
    return (tmc2209_get_version(&s_drv, version) == TMC2209_OK) ? 0 : -1;
}

int TMC2209_GetDrvStatus(tmc2209_drv_status_t *st)
{
    if (!s_tmc_ready || !st) return -1;
    return (tmc2209_get_drv_status(&s_drv, st) == TMC2209_OK) ? 0 : -1;
}

/* Возвращает последний закэшированный DRV_STATUS без блокировки.
 * Кэш обновляется через TMC2209_Task() каждые DIAG_INTERVAL_MS мс.
 * Возвращает 0 если кэш валиден, -1 если данных ещё нет.
 */
int TMC2209_GetCachedDrvStatus(tmc2209_drv_status_t *st)
{
    if (!s_diag_valid || !st) return -1;
    *st = s_diag_cached;
    return 0;
}
